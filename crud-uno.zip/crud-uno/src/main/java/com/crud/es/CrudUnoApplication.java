package com.crud.es;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudUnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudUnoApplication.class, args);
	}

}
